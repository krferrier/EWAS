#ifndef __VERSION_INFO_H__
#define __VERSION_INFO_H__


#ifndef VERSION 
#define VERSION "2020-05-05"
#endif


#endif


